.. automodule:: nimfa.methods.factorization.snmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: