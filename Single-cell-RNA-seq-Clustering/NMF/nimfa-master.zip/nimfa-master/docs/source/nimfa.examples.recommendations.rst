.. automodule:: nimfa.examples.recommendations
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
	
.. comment literalinclude:: ../../nimfa/examples/recommendations.py
	:lines: 43-173
	:linenos:
