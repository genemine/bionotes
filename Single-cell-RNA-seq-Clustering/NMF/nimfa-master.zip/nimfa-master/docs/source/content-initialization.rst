
 * **Random**

 * **Fixed**

 * **NNDSVD** [Boutsidis2007]_ 

 * **Random C** [Albright2006]_
 
 * **Random VCol** [Albright2006]_ 
