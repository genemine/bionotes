.. automodule:: nimfa.methods.factorization.lsnmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: