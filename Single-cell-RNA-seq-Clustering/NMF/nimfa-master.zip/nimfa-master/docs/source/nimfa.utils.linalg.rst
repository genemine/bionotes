.. automodule:: nimfa.utils.linalg
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	