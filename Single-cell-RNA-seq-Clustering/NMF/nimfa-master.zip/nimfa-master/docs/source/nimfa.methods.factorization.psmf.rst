.. automodule:: nimfa.methods.factorization.psmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: