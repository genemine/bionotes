.. automodule:: nimfa.methods.factorization.nmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: