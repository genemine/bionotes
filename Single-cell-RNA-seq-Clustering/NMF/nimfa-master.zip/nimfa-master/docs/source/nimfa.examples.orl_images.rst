.. automodule:: nimfa.examples.orl_images
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
	
.. comment literalinclude:: ../../nimfa/examples/orl_images.py
	:lines: 93-209
	:linenos:
