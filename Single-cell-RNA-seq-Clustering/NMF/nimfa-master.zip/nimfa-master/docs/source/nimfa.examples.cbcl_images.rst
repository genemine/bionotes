.. automodule:: nimfa.examples.cbcl_images
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
	
.. comment literalinclude:: ../../nimfa/examples/cbcl_images.py
	:lines: 82-198
	:linenos:
