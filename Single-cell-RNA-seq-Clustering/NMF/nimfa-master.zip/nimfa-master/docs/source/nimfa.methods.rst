#####################
Methods (``methods``)
#####################
    
.. automodule:: nimfa.methods
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	


.. toctree::
   :maxdepth: 3

   nimfa.methods.factorization
   
   nimfa.methods.seeding   

