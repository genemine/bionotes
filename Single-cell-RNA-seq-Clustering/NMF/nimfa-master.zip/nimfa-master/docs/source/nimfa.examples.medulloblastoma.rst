.. automodule:: nimfa.examples.medulloblastoma
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
	
.. comment literalinclude:: ../../nimfa/examples/medulloblastoma.py
	:lines: 96-199
	:linenos:
