.. automodule:: nimfa.methods.factorization.pmfcc
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	