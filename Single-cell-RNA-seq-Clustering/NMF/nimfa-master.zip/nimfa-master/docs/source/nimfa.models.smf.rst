.. automodule:: nimfa.models.smf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	