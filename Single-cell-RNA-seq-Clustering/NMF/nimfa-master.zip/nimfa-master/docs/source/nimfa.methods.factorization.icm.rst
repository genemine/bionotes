.. automodule:: nimfa.methods.factorization.icm
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: