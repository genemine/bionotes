#############################
Seeding (``methods.seeding``)
#############################
    
.. automodule:: nimfa.methods.seeding
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:	


.. toctree::
   :maxdepth: 2

   nimfa.methods.seeding.nndsvd
   
   nimfa.methods.seeding.random_c
   
   nimfa.methods.seeding.random_vcol
   
   nimfa.methods.seeding.random
   
   nimfa.methods.seeding.fixed
   

