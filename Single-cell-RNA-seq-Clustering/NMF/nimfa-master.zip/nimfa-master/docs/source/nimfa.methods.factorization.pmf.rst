.. automodule:: nimfa.methods.factorization.pmf
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance: