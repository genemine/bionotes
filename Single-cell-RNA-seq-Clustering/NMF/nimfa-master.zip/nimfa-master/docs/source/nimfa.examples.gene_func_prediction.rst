.. automodule:: nimfa.examples.gene_func_prediction
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
	
.. comment literalinclude:: ../../nimfa/examples/gene_func_prediction.py
	:lines: 57-461
	:linenos:
