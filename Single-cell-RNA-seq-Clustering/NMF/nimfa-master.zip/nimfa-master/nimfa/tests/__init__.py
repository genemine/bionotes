"""Various tests for nimfa code"""
